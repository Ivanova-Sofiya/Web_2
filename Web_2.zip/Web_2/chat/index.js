
var express = require('express');
var app = express();
var server = require('http').createServer(app);
var io = require('socket.io')(server); 
var fs = require('fs');


server.listen(3000, () => {
  console.log('listening on :3002 - chat');
});

app.get('/', function (request, respons) {
    respons.sendFile(__dirname + '/index.html');
});

app.use(express.static(__dirname + "../public"));

connections = [];

function sleep(milliseconds) {
    const date = Date.now();
    let currentDate = null;
    do {
        currentDate = Date.now();
    } while (currentDate - date < milliseconds);
}


const chat_mess = []
const chat_name = []
const chat_class = []


let fileContent = fs.readFileSync("chat.txt", "utf8");

var fileContent1 = fileContent.substring(0, fileContent.length - 1);

if (fileContent.length != 0) {

    key = fileContent1.split('')

    key.forEach(function (item, j, key) {
        key2 = item.split("_");
        chat_mess[j] = key2[0];
        chat_name[j] = key2[1];
        chat_class[j] = key2[2];
    });
}

io.sockets.on('connection', function (socket) {
    console.log("Connection is successful");
    connections.push(socket);
    //вывод с базы
    if (chat_mess.length != 0 && chat_name.length != 0 && chat_class.length != 0)
        for (let i = 0; i < chat_name.length; i++) {
            socket.emit('add history', { mess: chat_mess[i], name: chat_name[i], className: chat_class[i] });
        }

    socket.on('disconnect', function (data) {
        connections.splice(connections.indexOf(socket), 1);
        console.log("Disconnect");
        if (chat_mess.length != 0 && chat_name.length != 0 && chat_class.length != 0)
            fs.writeFileSync("chat.txt", "Сообщение: " + chat_mess[0] + ";  Имя пользователя: " + chat_name[0] + ";  Используемый класс: " + chat_class[0] + "\n");
        for (let i = 1; i < chat_name.length; i++) {
            fs.appendFileSync("chat.txt", "Сообщение: " + chat_mess[i] + ";  Имя пользователя: " + chat_name[i] + ";  Используемый класс: " + chat_class[i] + "\n>");
        }
    });

    socket.on('send mess', function (data) {
        
        chat_mess.push(data.mess)
        chat_name.push(data.name)
        chat_class.push(data.className)
        io.sockets.emit('add mess', { mess: data.mess, name: data.name, className: data.className });
    });


});